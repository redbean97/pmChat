package com.dinhluc.user.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dinhluc.user.dto.UpdateRequest;
import com.dinhluc.user.entities.UserEntity;
import com.dinhluc.user.repositories.ListPage;
import com.dinhluc.user.repositories.UserRepository;
import com.dinhluc.user.services.IUserService;
import com.dinhluc.user.services.UserDetailsImpl;
import com.dinhluc.user.services.UserDetailsServiceImpl;
import com.dinhluc.user.services.impl.UserService;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/test")
public class TestApi {
	
	@Autowired
	ListPage listUser;
	
	@GetMapping("/all")
	public String allAccess() {
		return "Public Content.";
	}
	
	@GetMapping("/user")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public String userAccess() {
		return "User Content.";
	}

	@GetMapping("/list")
	@PreAuthorize("hasRole('ADMIN')")
	public List<UserEntity> retrieveAllStudents() {
		return listUser.findAll();
	}
	
	@Autowired
	private IUserService userService;
	
	@DeleteMapping("/admin")
	@PreAuthorize("hasRole('ADMIN')")
	public void deleteUser(@RequestBody long[] ids) {
		userService.delete(ids);
	}
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Autowired
	private UserDetailsServiceImpl userDetailsService;
	
	@Autowired
	UserRepository userRepository;
	
	@PutMapping("/update")
	@PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	public void updatePassword(@RequestBody UpdateRequest UpRequest) {
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
		    String username = ((UserDetails) principal).getUsername();
		} else {
		    String username = principal.toString();
		}
		UserDetails userDetails = userDetailsService.loadUserByUsername(((UserDetails)principal).getUsername());
		if (passwordEncoder.matches(UpRequest.getOldPassword(), userDetails.getPassword())) {
			
		}
	}
}
