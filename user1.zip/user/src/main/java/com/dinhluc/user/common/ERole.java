package com.dinhluc.user.common;

public enum ERole {
	ROLE_USER,
	ROLE_ADMIN
}
