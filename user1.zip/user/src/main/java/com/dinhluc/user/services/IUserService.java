package com.dinhluc.user.services;


public interface IUserService {
	//NewDTO update(NewDTO newDTO);
	void delete(long[] ids);
}
