package com.dinhluc.user.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dinhluc.user.entities.UserEntity;

public interface ListPage extends JpaRepository<UserEntity, Long> {
	  
}